#ifndef LOGINW_H
#define LOGINW_H

#include <QWidget>
#include <QPushButton>
#include<QLabel.h>
#include<QLineEdit.h>

class loginW : public QWidget
{
    Q_OBJECT
public:
    explicit loginW(QWidget *parent = 0);

signals:
    void loginsuccess(); //申明信号

public slots:
    void xxx()
    {
        emit loginsuccess(); //发射信号
        close();
    }

private:
    QPushButton *bt;
    QPushButton *bt1;
    QPushButton *bt2;
};

#endif // LOGINW_H
