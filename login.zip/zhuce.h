#ifndef ZHUCE_H
#define ZHUCE_H

#include <QWidget>
#include "loginw.h"

namespace Ui {
class zhuce;
}

class zhuce : public QWidget
{
    Q_OBJECT

public:
    explicit zhuce(QWidget *parent = nullptr);
    ~zhuce();

private:
    Ui::zhuce *ui;
    loginW *zhu;
signals:
    void back();
};

#endif // ZHUCE_H
