#include "zhoahui.h"
#include "ui_zhoahui.h"

zhoahui::zhoahui(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::zhoahui)
{
    ui->setupUi(this);
    QPushButton *b2 = new QPushButton("返回登陆",this);
    b2->resize(90,29);
    b2->move(350,280);
    connect(b2,&QPushButton::clicked,[=](){
                emit this->back();
        });
}

zhoahui::~zhoahui()
{
    delete ui;
}
