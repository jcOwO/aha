#include "zhuce.h"
#include "ui_zhuce.h"

zhuce::zhuce(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::zhuce)
{
    ui->setupUi(this);
    QPushButton *b2 = new QPushButton("返回登陆",this);
    b2->resize(90,29);
    b2->move(350,220);
    connect(b2,&QPushButton::clicked,[=](){
                emit this->back();
            });
}

zhuce::~zhuce()
{
    delete ui;
}

