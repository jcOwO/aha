#include "loginw.h"
#include "zhuce.h"
#include "zhoahui.h"


loginW::loginW(QWidget *parent) : QWidget(parent)
{

    this->resize(500,300);
    this->setWindowTitle("虚数智子");

    bt = new QPushButton("登陆", this);
    bt->resize(100,30);
    bt->move(350,200);

    bt1=new QPushButton("注册",this);
    bt1->resize(100,30);
    bt1->move(50,200);

    bt2 = new QPushButton("找回", this);
    bt2->resize(100,30);
    bt2->move(200,200);


    connect(bt, SIGNAL(clicked(bool)), this, SLOT(xxx()));

    QLineEdit *line1=new  QLineEdit("",this);
    line1->setGeometry(QRect(QPoint(150, 120), QSize(200, 20)));

    QLineEdit *line2=new  QLineEdit("",this);
    line2->setGeometry(QRect(QPoint(150, 150), QSize(200, 20)));
    line2->setEchoMode(QLineEdit::Password);

    QLabel *Label1 = new QLabel(this);
    Label1->setText("主题");
    Label1->setGeometry(190,20,200,40);
    QFont ft;
    ft.setPointSize(20);
    Label1->setFont(ft);
    Label1->setStyleSheet("color:green");

    QLabel *Label2 = new QLabel(this);
    Label2->setText("账号");
    Label2->setGeometry(110,110,30,40);//x，y，长，宽

    QLabel *Label3 = new QLabel(this);
    Label3->setText("密码");
    Label3->setGeometry(110,140,30,40);

    zhuce *s = new zhuce();
    connect(bt1,&QPushButton::clicked,[=](){
                this->hide();
                s->show();
            });
    connect(s,&zhuce::back,[=](){
                s->hide();
                this->show();
            });

    zhoahui *c = new zhoahui();
    connect(bt2,&QPushButton::clicked,[=](){
                this->hide();
                c->show();
            });
    connect(c,&zhoahui::back,[=](){
                c->hide();
                this->show();
            });
}

