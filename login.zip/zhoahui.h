#ifndef ZHOAHUI_H
#define ZHOAHUI_H

#include <QWidget>
#include "loginw.h"

namespace Ui {
class zhoahui;
}

class zhoahui : public QWidget
{
    Q_OBJECT

public:
    explicit zhoahui(QWidget *parent = 0);
    ~zhoahui();

private:
    Ui::zhoahui *ui;
    loginW *zhao;
signals:
    void back();
};

#endif // ZHOAHUI_H
