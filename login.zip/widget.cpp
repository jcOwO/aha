#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    login = new loginW;
    login->show();
    connect(login, SIGNAL(loginsuccess()), this, SLOT(show()));
}

Widget::~Widget()
{
    delete ui;
}
